-- JasonExecutor Custom Global Chat UI
-- Ce script crée une interface de chat personnalisée côté client.
-- Il utilise les événements de chat par défaut de Roblox pour envoyer et recevoir des messages,
-- ce qui permet aux messages d'être vus par tout le monde dans le serveur.

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TextChatService = game:GetService("TextChatService")
local CoreGui = game:GetService("CoreGui")
local UserInputService = game:GetService("UserInputService")

local localPlayer = Players.LocalPlayer

-- Nettoyage de l'ancienne interface si elle existe déjà
if CoreGui:FindFirstChild("JasonCustomChat") then
    CoreGui.JasonCustomChat:Destroy()
end

-- Création de l'interface principale
local screenGui = Instance.new("ScreenGui")
screenGui.Name = "JasonCustomChat"
screenGui.ResetOnSpawn = false
-- Utilisation de CoreGui pour cacher le GUI de l'explorateur du jeu (si exécuté via un executor)
local success, err = pcall(function()
    screenGui.Parent = CoreGui
end)
if not success then
    screenGui.Parent = localPlayer:WaitForChild("PlayerGui")
end

-- Fenêtre principale
local mainFrame = Instance.new("Frame")
mainFrame.Name = "MainFrame"
mainFrame.Size = UDim2.new(0, 400, 0, 300)
mainFrame.Position = UDim2.new(0.5, -200, 0.5, -150)
mainFrame.BackgroundColor3 = Color3.fromRGB(20, 20, 20)
mainFrame.BorderSizePixel = 0
mainFrame.Active = true
mainFrame.Draggable = true -- Rend la fenêtre déplaçable (fonctionnalité basique)
mainFrame.Parent = screenGui

local uiCorner = Instance.new("UICorner")
uiCorner.CornerRadius = UDim.new(0, 8)
uiCorner.Parent = mainFrame

local titleBar = Instance.new("Frame")
titleBar.Name = "TitleBar"
titleBar.Size = UDim2.new(1, 0, 0, 30)
titleBar.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
titleBar.BorderSizePixel = 0
titleBar.Parent = mainFrame

local titleCorner = Instance.new("UICorner")
titleCorner.CornerRadius = UDim.new(0, 8)
titleCorner.Parent = titleBar

-- Cacher les coins inférieurs de la barre de titre
local titleFix = Instance.new("Frame")
titleFix.Size = UDim2.new(1, 0, 0, 5)
titleFix.Position = UDim2.new(0, 0, 1, -5)
titleFix.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
titleFix.BorderSizePixel = 0
titleFix.Parent = titleBar

local titleLabel = Instance.new("TextLabel")
titleLabel.Size = UDim2.new(1, -20, 1, 0)
titleLabel.Position = UDim2.new(0, 10, 0, 0)
titleLabel.BackgroundTransparency = 1
titleLabel.Text = "JasonExecutor - Global Chat"
titleLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
titleLabel.Font = Enum.Font.GothamBold
titleLabel.TextSize = 14
titleLabel.TextXAlignment = Enum.TextXAlignment.Left
titleLabel.Parent = titleBar

local chatScroll = Instance.new("ScrollingFrame")
chatScroll.Name = "ChatScroll"
chatScroll.Size = UDim2.new(1, -20, 1, -80)
chatScroll.Position = UDim2.new(0, 10, 0, 40)
chatScroll.BackgroundTransparency = 1
chatScroll.BorderSizePixel = 0
chatScroll.ScrollBarThickness = 4
chatScroll.CanvasSize = UDim2.new(0, 0, 0, 0)
chatScroll.AutomaticCanvasSize = Enum.AutomaticSize.Y
chatScroll.Parent = mainFrame

local uiListLayout = Instance.new("UIListLayout")
uiListLayout.SortOrder = Enum.SortOrder.LayoutOrder
uiListLayout.Padding = UDim.new(0, 5)
uiListLayout.Parent = chatScroll

local inputFrame = Instance.new("Frame")
inputFrame.Name = "InputFrame"
inputFrame.Size = UDim2.new(1, -20, 0, 30)
inputFrame.Position = UDim2.new(0, 10, 1, -35)
inputFrame.BackgroundColor3 = Color3.fromRGB(40, 40, 40)
inputFrame.BorderSizePixel = 0
inputFrame.Parent = mainFrame

local inputCorner = Instance.new("UICorner")
inputCorner.CornerRadius = UDim.new(0, 4)
inputCorner.Parent = inputFrame

local chatInput = Instance.new("TextBox")
chatInput.Name = "ChatInput"
chatInput.Size = UDim2.new(1, -10, 1, 0)
chatInput.Position = UDim2.new(0, 5, 0, 0)
chatInput.BackgroundTransparency = 1
chatInput.Text = ""
chatInput.PlaceholderText = "Tapez un message ici et appuyez sur Entrée..."
chatInput.TextColor3 = Color3.fromRGB(255, 255, 255)
chatInput.PlaceholderColor3 = Color3.fromRGB(150, 150, 150)
chatInput.Font = Enum.Font.Gotham
chatInput.TextSize = 13
chatInput.TextXAlignment = Enum.TextXAlignment.Left
chatInput.ClearTextOnFocus = false
chatInput.Parent = inputFrame

-- Fonction pour ajouter un message à l'interface
local function addMessage(sender, message, isSystem)
    local msgFrame = Instance.new("Frame")
    msgFrame.Size = UDim2.new(1, -10, 0, 20)
    msgFrame.BackgroundTransparency = 1
    msgFrame.AutomaticSize = Enum.AutomaticSize.Y
    
    local txt = Instance.new("TextLabel")
    txt.Size = UDim2.new(1, 0, 1, 0)
    txt.BackgroundTransparency = 1
    txt.TextWrapped = true
    txt.Font = Enum.Font.Gotham
    txt.TextSize = 13
    txt.TextXAlignment = Enum.TextXAlignment.Left
    txt.TextYAlignment = Enum.TextYAlignment.Top
    txt.AutomaticSize = Enum.AutomaticSize.Y
    
    if isSystem then
        txt.Text = "[SYSTEM]: " .. message
        txt.TextColor3 = Color3.fromRGB(255, 100, 100)
    else
        txt.Text = "[" .. sender .. "]: " .. message
        txt.TextColor3 = Color3.fromRGB(220, 220, 220)
    end
    
    txt.Parent = msgFrame
    msgFrame.Parent = chatScroll
    
    -- Auto-scroll vers le bas
    task.spawn(function()
        task.wait(0.05)
        chatScroll.CanvasPosition = Vector2.new(0, chatScroll.AbsoluteWindowSize.Y + 9999)
    end)
end

-- Gestion de l'envoi de message
chatInput.FocusLost:Connect(function(enterPressed)
    if enterPressed and chatInput.Text ~= "" then
        local msg = chatInput.Text
        chatInput.Text = ""
        
        -- Envoi du message via TextChatService (nouveau système de chat)
        if TextChatService.ChatVersion == Enum.ChatVersion.TextChatService then
            local channel = TextChatService.TextChannels:FindFirstChild("RBXGeneral")
            if channel then
                channel:SendAsync(msg)
            else
                addMessage("Erreur", "Canal RBXGeneral introuvable.", true)
            end
        else
            -- Envoi du message via le système de chat classique (Legacy)
            local sayMsgRequest = ReplicatedStorage:FindFirstChild("DefaultChatSystemChatEvents")
            if sayMsgRequest and sayMsgRequest:FindFirstChild("SayMessageRequest") then
                sayMsgRequest.SayMessageRequest:FireServer(msg, "All")
            else
                addMessage("Erreur", "Système de chat legacy introuvable.", true)
            end
        end
    end
end)

-- Écoute des messages entrants
if TextChatService.ChatVersion == Enum.ChatVersion.TextChatService then
    TextChatService.MessageReceived:Connect(function(textChatMessage)
        if textChatMessage.TextSource then
            local senderName = textChatMessage.TextSource.Name
            addMessage(senderName, textChatMessage.Text, false)
        end
    end)
else
    local onMsgDone = ReplicatedStorage:FindFirstChild("DefaultChatSystemChatEvents")
    if onMsgDone and onMsgDone:FindFirstChild("OnMessageDoneFiltering") then
        onMsgDone.OnMessageDoneFiltering.OnClientEvent:Connect(function(messageData)
            addMessage(messageData.FromSpeaker, messageData.Message, false)
        end)
    end
end

addMessage("JasonIA", "Chat global injecté avec succès. Les messages envoyés ici seront visibles par tous les joueurs du serveur.", true)

-- Code pour rendre la fenêtre glissable de façon fluide (Smooth Dragging)
local dragging
local dragInput
local dragStart
local startPos

local function update(input)
    local delta = input.Position - dragStart
    mainFrame.Position = UDim2.new(startPos.X.Scale, startPos.X.Offset + delta.X, startPos.Y.Scale, startPos.Y.Offset + delta.Y)
end

titleBar.InputBegan:Connect(function(input)
    if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
        dragging = true
        dragStart = input.Position
        startPos = mainFrame.Position
        
        input.Changed:Connect(function()
            if input.UserInputState == Enum.UserInputState.End then
                dragging = false
            end
        end)
    end
end)

titleBar.InputChanged:Connect(function(input)
    if input.UserInputType == Enum.UserInputType.MouseMovement or input.UserInputType == Enum.UserInputType.Touch then
        dragInput = input
    end
end)

UserInputService.InputChanged:Connect(function(input)
    if input == dragInput and dragging then
        update(input)
    end
end)
