-- JasonExecutor Custom Global Chat UI v2.0 [Bypass Edition]
-- Implémente des techniques de bypass de filtre de chat (Zero-Width Characters & Rich Text Mixing)
-- Note: Les filtres Roblox sont mis à jour fréquemment, ces méthodes sont éducatives.

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TextChatService = game:GetService("TextChatService")
local CoreGui = game:GetService("CoreGui")
local UserInputService = game:GetService("UserInputService")
local TweenService = game:GetService("TweenService")

local localPlayer = Players.LocalPlayer

-- ==========================================
-- BYPASS ALGORITHMS (2024 Methods)
-- ==========================================

-- 1. Zero-Width Joiner (ZWJ) Insertion
-- Insère des caractères invisibles entre chaque lettre pour perturber l'analyse du filtre
local function applyZWJBypass(text)
    local zwj = utf8.char(0x200B) -- Zero-width space
    local bypassed = ""
    for i = 1, #text do
        bypassed = bypassed .. string.sub(text, i, i) .. zwj
    end
    return bypassed
end

-- 2. Rich Text Tag Obfuscation
-- Enveloppe des lettres dans des tags de police factices pour casser la reconnaissance de mots
local function applyRichTextBypass(text)
    local bypassed = ""
    for i = 1, #text do
        bypassed = bypassed .. "<font size='13'>" .. string.sub(text, i, i) .. "</font>"
    end
    return bypassed
end

-- Fonction globale de bypass (Combine les méthodes selon les cas)
local function obfuscateMessage(text)
    -- On applique la méthode ZWJ par défaut car elle est moins intrusive visuellement
    -- si le chat supporte mal le Rich Text
    return applyZWJBypass(text)
end

-- ==========================================
-- GUI SETUP
-- ==========================================

if CoreGui:FindFirstChild("JasonCustomChatV2") then
    CoreGui.JasonCustomChatV2:Destroy()
end

local screenGui = Instance.new("ScreenGui")
screenGui.Name = "JasonCustomChatV2"
screenGui.ResetOnSpawn = false
local success = pcall(function() screenGui.Parent = CoreGui end)
if not success then screenGui.Parent = localPlayer:WaitForChild("PlayerGui") end

-- Fenêtre principale translucide (Glassmorphism)
local mainFrame = Instance.new("Frame")
mainFrame.Name = "MainFrame"
mainFrame.Size = UDim2.new(0, 420, 0, 320)
mainFrame.Position = UDim2.new(0.5, -210, 0.5, -160)
mainFrame.BackgroundColor3 = Color3.fromRGB(15, 15, 15)
mainFrame.BackgroundTransparency = 0.2
mainFrame.BorderSizePixel = 0
mainFrame.Active = true
mainFrame.Draggable = true
mainFrame.Parent = screenGui

local uiCorner = Instance.new("UICorner")
uiCorner.CornerRadius = UDim.new(0, 10)
uiCorner.Parent = mainFrame

local uiStroke = Instance.new("UIStroke")
uiStroke.Color = Color3.fromRGB(255, 255, 255)
uiStroke.Transparency = 0.8
uiStroke.Thickness = 1
uiStroke.Parent = mainFrame

-- Barre de titre
local titleBar = Instance.new("Frame")
titleBar.Size = UDim2.new(1, 0, 0, 35)
titleBar.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
titleBar.BackgroundTransparency = 0.5
titleBar.BorderSizePixel = 0
titleBar.Parent = mainFrame
Instance.new("UICorner", titleBar).CornerRadius = UDim.new(0, 10)

-- Cache coin bas de la barre
local titleFix = Instance.new("Frame")
titleFix.Size = UDim2.new(1, 0, 0, 10)
titleFix.Position = UDim2.new(0, 0, 1, -10)
titleFix.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
titleFix.BackgroundTransparency = 0.5
titleFix.BorderSizePixel = 0
titleFix.Parent = titleBar

local titleLabel = Instance.new("TextLabel")
titleLabel.Size = UDim2.new(1, -20, 1, 0)
titleLabel.Position = UDim2.new(0, 15, 0, 0)
titleLabel.BackgroundTransparency = 1
titleLabel.Text = "JASON EXECUTOR // GLOBAL CHAT V2.0"
titleLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
titleLabel.Font = Enum.Font.GothamBlack
titleLabel.TextSize = 12
titleLabel.TextXAlignment = Enum.TextXAlignment.Left
titleLabel.Parent = titleBar

-- Zone de messages
local chatScroll = Instance.new("ScrollingFrame")
chatScroll.Size = UDim2.new(1, -30, 1, -95)
chatScroll.Position = UDim2.new(0, 15, 0, 45)
chatScroll.BackgroundTransparency = 1
chatScroll.BorderSizePixel = 0
chatScroll.ScrollBarThickness = 2
chatScroll.ScrollBarImageColor3 = Color3.fromRGB(255, 255, 255)
chatScroll.CanvasSize = UDim2.new(0, 0, 0, 0)
chatScroll.AutomaticCanvasSize = Enum.AutomaticSize.Y
chatScroll.Parent = mainFrame

local uiListLayout = Instance.new("UIListLayout")
uiListLayout.SortOrder = Enum.SortOrder.LayoutOrder
uiListLayout.Padding = UDim.new(0, 8)
uiListLayout.Parent = chatScroll

-- Checkbox Bypass
local bypassFrame = Instance.new("Frame")
bypassFrame.Size = UDim2.new(0, 150, 0, 20)
bypassFrame.Position = UDim2.new(0, 15, 1, -45)
bypassFrame.BackgroundTransparency = 1
bypassFrame.Parent = mainFrame

local bypassToggle = Instance.new("TextButton")
bypassToggle.Size = UDim2.new(0, 16, 0, 16)
bypassToggle.Position = UDim2.new(0, 0, 0.5, -8)
bypassToggle.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
bypassToggle.Text = "✓"
bypassToggle.TextColor3 = Color3.fromRGB(255, 255, 255)
bypassToggle.Font = Enum.Font.GothamBold
bypassToggle.TextSize = 12
Instance.new("UICorner", bypassToggle).CornerRadius = UDim.new(0, 4)
Instance.new("UIStroke", bypassToggle).Color = Color3.fromRGB(255, 255, 255)
Instance.new("UIStroke", bypassToggle).Transparency = 0.5
bypassToggle.Parent = bypassFrame

local bypassLabel = Instance.new("TextLabel")
bypassLabel.Size = UDim2.new(1, -25, 1, 0)
bypassLabel.Position = UDim2.new(0, 25, 0, 0)
bypassLabel.BackgroundTransparency = 1
bypassLabel.Text = "Enable Filter Bypass"
bypassLabel.TextColor3 = Color3.fromRGB(200, 200, 200)
bypassLabel.Font = Enum.Font.Gotham
bypassLabel.TextSize = 12
bypassLabel.TextXAlignment = Enum.TextXAlignment.Left
bypassLabel.Parent = bypassFrame

local useBypass = true
bypassToggle.MouseButton1Click:Connect(function()
    useBypass = not useBypass
    if useBypass then
        bypassToggle.Text = "✓"
        bypassToggle.BackgroundColor3 = Color3.fromRGB(50, 50, 50)
    else
        bypassToggle.Text = ""
        bypassToggle.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
    end
end)

-- Zone de saisie
local inputFrame = Instance.new("Frame")
inputFrame.Size = UDim2.new(1, -30, 0, 35)
inputFrame.Position = UDim2.new(0, 15, 1, -85)
inputFrame.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
inputFrame.BackgroundTransparency = 0.5
inputFrame.BorderSizePixel = 0
inputFrame.Parent = mainFrame
Instance.new("UICorner", inputFrame).CornerRadius = UDim.new(0, 6)
Instance.new("UIStroke", inputFrame).Color = Color3.fromRGB(255, 255, 255)
Instance.new("UIStroke", inputFrame).Transparency = 0.8

local chatInput = Instance.new("TextBox")
chatInput.Size = UDim2.new(1, -20, 1, 0)
chatInput.Position = UDim2.new(0, 10, 0, 0)
chatInput.BackgroundTransparency = 1
chatInput.Text = ""
chatInput.PlaceholderText = "Type message..."
chatInput.TextColor3 = Color3.fromRGB(255, 255, 255)
chatInput.PlaceholderColor3 = Color3.fromRGB(150, 150, 150)
chatInput.Font = Enum.Font.Gotham
chatInput.TextSize = 13
chatInput.TextXAlignment = Enum.TextXAlignment.Left
chatInput.ClearTextOnFocus = false
chatInput.Parent = inputFrame

-- ==========================================
-- CHAT LOGIC
-- ==========================================

local function addMessage(sender, message, isSystem)
    local msgFrame = Instance.new("Frame")
    msgFrame.Size = UDim2.new(1, -10, 0, 20)
    msgFrame.BackgroundTransparency = 1
    msgFrame.AutomaticSize = Enum.AutomaticSize.Y
    
    local txt = Instance.new("TextLabel")
    txt.Size = UDim2.new(1, 0, 1, 0)
    txt.BackgroundTransparency = 1
    txt.TextWrapped = true
    txt.RichText = true
    txt.Font = Enum.Font.Gotham
    txt.TextSize = 13
    txt.TextXAlignment = Enum.TextXAlignment.Left
    txt.TextYAlignment = Enum.TextYAlignment.Top
    txt.AutomaticSize = Enum.AutomaticSize.Y
    
    if isSystem then
        txt.Text = "<b>[SYS]</b> " .. message
        txt.TextColor3 = Color3.fromRGB(180, 180, 180)
    else
        local colorPrefix = sender == localPlayer.Name and "<b><font color='rgb(255,255,255)'>" or "<b><font color='rgb(150,150,150)'>"
        txt.Text = colorPrefix .. "[" .. sender .. "]</font></b> " .. message
        txt.TextColor3 = Color3.fromRGB(255, 255, 255)
    end
    
    txt.Parent = msgFrame
    msgFrame.Parent = chatScroll
    
    -- Animation d'apparition
    msgFrame.BackgroundTransparency = 1
    txt.TextTransparency = 1
    TweenService:Create(txt, TweenInfo.new(0.3), {TextTransparency = 0}):Play()
    
    task.spawn(function()
        task.wait(0.05)
        TweenService:Create(chatScroll, TweenInfo.new(0.2), {CanvasPosition = Vector2.new(0, chatScroll.AbsoluteWindowSize.Y + 9999)}):Play()
    end)
end

-- Envoi
chatInput.FocusLost:Connect(function(enter)
    if enter and chatInput.Text ~= "" then
        local originalMsg = chatInput.Text
        local finalMsg = useBypass and obfuscateMessage(originalMsg) or originalMsg
        chatInput.Text = ""
        
        -- Bypass execution logic
        if TextChatService.ChatVersion == Enum.ChatVersion.TextChatService then
            local channel = TextChatService.TextChannels:FindFirstChild("RBXGeneral")
            if channel then
                channel:SendAsync(finalMsg)
            else
                addMessage("Erreur", "RBXGeneral introuvable.", true)
            end
        else
            local sayMsgRequest = ReplicatedStorage:FindFirstChild("DefaultChatSystemChatEvents")
            if sayMsgRequest and sayMsgRequest:FindFirstChild("SayMessageRequest") then
                sayMsgRequest.SayMessageRequest:FireServer(finalMsg, "All")
            else
                addMessage("Erreur", "Legacy Chat introuvable.", true)
            end
        end
    end
end)

-- Réception
if TextChatService.ChatVersion == Enum.ChatVersion.TextChatService then
    TextChatService.MessageReceived:Connect(function(msg)
        if msg.TextSource then
            -- Nettoie les caractères de bypass pour l'affichage local si c'est nous
            local cleanText = msg.Text:gsub(utf8.char(0x200B), "")
            addMessage(msg.TextSource.Name, cleanText, false)
        end
    end)
else
    local onMsgDone = ReplicatedStorage:FindFirstChild("DefaultChatSystemChatEvents")
    if onMsgDone and onMsgDone:FindFirstChild("OnMessageDoneFiltering") then
        onMsgDone.OnMessageDoneFiltering.OnClientEvent:Connect(function(data)
            local cleanText = data.Message:gsub(utf8.char(0x200B), "")
            addMessage(data.FromSpeaker, cleanText, false)
        end)
    end
end

-- Init system message
addMessage("JasonIA", "Chat v2.0 Initialized. Bypass module: <font color='rgb(100,255,100)'>ONLINE</font>.", true)

-- Smooth Dragging Logic
local dragging, dragInput, dragStart, startPos

titleBar.InputBegan:Connect(function(input)
    if input.UserInputType == Enum.UserInputType.MouseButton1 then
        dragging = true
        dragStart = input.Position
        startPos = mainFrame.Position
        input.Changed:Connect(function()
            if input.UserInputState == Enum.UserInputState.End then dragging = false end
        end)
    end
end)

titleBar.InputChanged:Connect(function(input)
    if input.UserInputType == Enum.UserInputType.MouseMovement then dragInput = input end
end)

UserInputService.InputChanged:Connect(function(input)
    if input == dragInput and dragging then
        local delta = input.Position - dragStart
        mainFrame.Position = UDim2.new(startPos.X.Scale, startPos.X.Offset + delta.X, startPos.Y.Scale, startPos.Y.Offset + delta.Y)
    end
end)
